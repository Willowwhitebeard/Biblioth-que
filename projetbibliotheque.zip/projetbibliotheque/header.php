<!DOCTYPE html>
<head>
	<meta charset="UTF-8">
  <link rel="stylesheet" href="style.css">
	<title>Ma bibliothèque</title>
</head>
	
<body>
	<header>
		<nav class="navbar">
      <h1 class="titre_du_site">Ma bibliothèque</a></h1>
      <div>
          <a href="accueil.php"><img class="logo" src="img/logo.jpg" alt="logo"></a>
        </div>
          <ul class="nav_bar">
            <li class="liens_menu"><a href="accueil.php">Accueil</a></li>
            <li class="liens_menu"><a href="touslivres.php">Tous les livres</a></li>
            <li class="liens_menu"><a href="auteur.php">Par auteur</a></li>
            <li class="liens_menu"><a href="nouveau.php">Nouveau livre</a></li>
			<li class="liens_menu"><a href="recherche.php">Recherche</a></li>
			
          </ul>
    </nav>
      </div>
	</header>
</body>