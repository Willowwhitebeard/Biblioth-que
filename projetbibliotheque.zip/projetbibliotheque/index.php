<?php include "header.php"; ?>

<h2>Tous les livres</h2>
<?php
try 
{
	$bdd = new PDO('mysql:host=localhost;dbname=bibliotheque_script;charset=utf8', 'root', '');
}
catch (Exception $e)
{
    die('Erreur : ' . $e->getMessage());
}
$accueil = $bdd -> query('SELECT titre, nom_fichier FROM livre JOIN images ON livre.isbn = images.id;');
while ($donnees = $accueil-> fetch()){
?>
	<div id="touslivres">
		<div id="livre">
			<img src="<?php echo $donnees['nom_fichier']; ?>">
				<h3><b>Titre : </b><?php echo $donnees['livre.titre']; ?></h3>
				<p><a href="kafka.php">Voir les détails</a></p>
		</div>
<?php
}
$accueil->closeCursor(); 
?>		