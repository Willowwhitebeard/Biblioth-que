<?php include "header.php"; ?>
<H2>Par auteur</H2>
<?php
try 
{
	$bdd = new PDO('mysql:host=localhost;dbname=bibliotheque_script;charset=utf8', 'root', '');
}
catch (Exception $e)
{
    die('Erreur : ' . $e->getMessage());
}
$reponse = $bdd -> query('SELECT DISTINCT idpersonne, nom, prenom FROM auteur JOIN personne on auteur.idPersonne = personne.id WHERE idrole = "1" ORDER BY nom;');
		while ($donnees = $reponse->fetch())
{
?>
<div id="tsauteur">
		<div id="auteur">
			<img src="img/<?php echo $donnees['idpersonne'];?>.jpg" alt ="Auteur">
			<h3><?php echo $donnees['nom'] . ' ' .$donnees['prenom'];?></h3>
			<p><a href="<?php echo $donnees['nom'];?>.php">Oeuvres disponibles</p>
		</div>
</div>
<?php
}
$reponse->closeCursor(); 
?>