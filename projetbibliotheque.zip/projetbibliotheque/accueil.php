<?php include "header.php"; ?>

<h2>Tous les livres</h2>
<?php
try 
{
	$bdd = new PDO('mysql:host=localhost;dbname=bibliotheque_script;charset=utf8', 'root', '');
}
catch (Exception $e)
{
    die('Erreur : ' . $e->getMessage());
}
$reponse = $bdd -> query('SELECT titre, isbn
	FROM livre;');
		while ($donnees = $reponse-> fetch())
{
?>
	<div id="accueil">
		<img src="C:\wamp64\www\projetbibliotheque\img\<?php echo $donnees['isbn']; ?>.jpg">
		<h3><b>Titre : </b><?php echo $donnees['titre']; ?></h3>
		<p><a href="touslivres.php">Voir les détails</a></p>
	
	</div>
<?php
}
$reponse->closeCursor(); 
?>		