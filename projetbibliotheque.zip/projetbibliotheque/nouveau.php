
<?php include "header.php"; ?>
<form action="" method="POST">
<br>saisir un isbn :<br/>
<input type="varchar" id="isbn" name="isbn" value="">
<br>saisir un titre :<br/>
<input type="varchar" id="titre" name="titre" value="">
<br>saisir un nom :<br/>
<input type="varchar" id="nom" name="nom" value="">
<br>saisir un prenom :<br/>
<input type="varchar" id="prenom" name="prenom" value="">
<br>saisir l'id de l'éditeur :<br/>
<input type="number" id="editeur" name="editeur" value="">
<br>saisir l'année de parution :<br/>
<input type="number" id="annee" name="annee" value="">
<br>saisir l'id du genre :<br/>
<input type="number" id="genre" name="genre" value="">
<br>saisir l'id de la langue :<br/>
<input type="number" id="langue" name="langue" value="">
<br>saisir le nombre de pages :<br/>
<input type="number" id="nbpages" name="nbpages" value="">
<input type="submit" name="submit" value="Enregistrer" />	
</form>
 
<?php


try{

	$bdd = new PDO('mysql:host=localhost;dbname=bibliotheque_script;charset=utf8', 'root', '');
}
catch(Exception $e){

	
    die('Erreur : '.$e->getMessage());
}
	
	
$reponse = $bdd->prepare(
'INSERT INTO bibliotheque_script.livre (isbn, titre, editeur, annee, genre, langue, nbpages) 
VALUES (:isbn, :titre, :editeur, :annee, :genre, :langue, :nbpages);

INSERT INTO bibliotheque_script.personne (nom, prenom)
VALUES (:nom, :prenom );

INSERT INTO bibliotheque_script.auteur (idLivre, idRole)
VALUES (:isbn, 1);

UPDATE bibliotheque_script.auteur
JOIN personne ON personne.id = auteur.idPersonne
JOIN role ON role.id = auteur.idRole
JOIN livre ON auteur.idLivre = livre.isbn
WHERE nom = :nom AND prenom = :prenom;');



$reponse->execute(array(
'isbn'=>$_POST['isbn'],
'titre'=>$_POST['titre'],
'nom'=>$_POST['nom'],
'prenom'=>$_POST['prenom'],
'editeur'=>$_POST['editeur'],
'annee'=>$_POST['annee'],
'genre'=>$_POST['genre'],
'langue'=>$_POST['langue'],
'nbpages'=>$_POST['nbpages']
));
var_dump($reponse);
echo 'Votre livre à été correctement inséré.';
?>

 

