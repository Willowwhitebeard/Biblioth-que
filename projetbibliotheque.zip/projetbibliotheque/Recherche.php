
<?php include "header.php"; ?>
<form action="" method="POST">
saisir un isbn :<br />
<input type="varchar" id="isbn" name="isbn" value="">
<input type="submit" name="submit" value="Valider"/>	
</form>
 
<?php


try{

	$bdd = new PDO('mysql:host=localhost;dbname=bibliotheque_script;charset=utf8', 'root', '');
}
catch(Exception $e){

	
    die('Erreur : '.$e->getMessage());
}
	
	
$reponse = $bdd->prepare('SELECT titre,isbn,nomediteur,annee,nomgenre,nomlangue,nbpages 
FROM livre 
JOIN images On livre.isbn = images.id
JOIN auteur ON livre.isbn = auteur.idLivre
JOIN role ON auteur.idRole = role.id
JOIN genre ON livre.genre = genre.id
JOIN personne ON auteur.idPersonne = personne.id
JOIN langue ON livre.langue = langue.id
JOIN editeur ON livre.editeur = editeur.id
WHERE isbn = :isbn');
$reponse->execute(array('isbn'=>$_POST['isbn']));
$donnees = $reponse->fetch();
$isbn = 'isbn'
?>

<strong>titre</strong> :<?php echo $donnees['titre']; ?><br/>
<br>L'ISBN est&nbsp;<?php echo $donnees['isbn']; ?><br/>
<br>l'editeur est&nbsp;<?php echo $donnees['nomediteur'];?><br/>
<br>L'année de parution est&nbsp;<?php echo $donnees['annee'];?><br/> 
<br>le genre du livre est&nbsp;<?php echo $donnees['nomgenre'];?><br/> 
<br>La langue du livre est le&nbsp;<?php echo $donnees['nomlangue'];?><br/>
<br>le nombre de pages est de&nbsp;<?php echo $donnees['nbpages'];?><br/>

<?php

$reponse->closeCursor(); 
?>