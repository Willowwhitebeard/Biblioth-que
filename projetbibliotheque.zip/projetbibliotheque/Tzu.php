<?php include "header.php"; ?>

<h2>Tous les livres</h2>
<?php
try 
{
	$bdd = new PDO('mysql:host=localhost;dbname=bibliotheque_script;charset=utf8', 'root', '');
}
catch (Exception $e)
{
    die('Erreur : ' . $e->getMessage());
}
$touslivres = $bdd -> query('SELECT *
	FROM livre
	JOIN images On livre.isbn = images.id
	JOIN auteur ON livre.isbn = auteur.idLivre
	JOIN role ON auteur.idRole = role.id
	JOIN genre ON livre.genre = genre.id
	JOIN personne ON auteur.idPersonne = personne.id
	JOIN langue ON livre.langue = langue.id
	JOIN editeur ON livre.editeur = editeur.id
	WHERE personne.nom = "Tzu";');
		while ($donnees = $touslivres-> fetch())
{
?>
	<div id="touslivres">
		<div id="livre">
			<h3><?php echo $donnees['titre']; ?></h3>
			<img src="img/<?php echo $donnees['isbn'];?>.jpg">
			<b><?php echo $donnees['nomrole']; ?> : 
			</b><?php echo $donnees['nom'].' '.$donnees['prenom']; ?></h3><br/>
			<b>Éditeur : </b><?php echo $donnees['nomediteur']; ?> <br/>
			<b>Genre : </b><?php echo $donnees['nomgenre']; ?><br/>
			<b>Langue : </b><?php echo $donnees['nomlangue']; ?><br/>
			<b>Nombre de pages : </b><?php echo $donnees['nbpages']; ?><br/>
			<b>Date de publication : </b><?php echo $donnees['annee']; ?><br/>
			</p>
		</div>
	</div>
<?php
}
$touslivres->closeCursor(); 
?>	